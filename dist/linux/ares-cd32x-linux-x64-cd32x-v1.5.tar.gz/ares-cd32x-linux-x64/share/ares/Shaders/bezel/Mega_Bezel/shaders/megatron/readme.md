/* 
Sony Megatron Colour Video Monitor
Author: Major Pain The Cactus

A shader that specifically tries to emulate arcade monitor's with an shadow mask screen but with full brightness. 

The novel thing about this shader is that it transforms the image output by the 'console/arcade/computer' into HDR space first i.e brightens it first and then applies 
an shadow mask afterwards which is kind of what a CRT would actually do - its kind of a kin to the electron beam (but nothing like it lol). 

My DisplayHDR 600 monitor does seem to get reasonably close to the brightness of my PVM - its not quite there but its close.  I think DisplayHDR 1000 and above will be able to match.

To use:
Please Enable HDR in RetroArch 1.10+
[UPDATE] This shader supports SDR as well - just enable it in the shader parameters

NOTE: when this shader is envoked the Contrast, Peak Luminance and Paper White Luminance in the HDR menu do nothing instead set those values through the shader parameters 

For this shader set Paper White Luminance to above 700 and Peak Luminance to the peak luminance of your monitor.   

Also try to use a integer scaling - its just better - overscaling is fine/great.

This shader doesn't do any geometry warping or bouncing of light around inside the screen - I think these effects just add unwanted noise, I know people disagree. Please feel free to make you own and add them

Works only with the D3D11/D3D12/Vulkan drivers currently

DONT USE THIS PRESET DIRECTLY - Use any of the others in this directory
*/

