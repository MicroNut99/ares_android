#pragma parameter hcrt_title                         "SONY MEGATRON COLOUR VIDEO MONITOR"                           0.0      0.0   0.0001   0.0001
#pragma parameter hcrt_space1                        " "                                                            0.0      0.0   0.0001   0.0001

#pragma parameter hcrt_user_settings                 "YOUR DISPLAY'S SETTINGS:"                                     0.0      0.0   0.0001   0.0001
#pragma parameter hcrt_max_nits                      "    Display's Peak Luminance"                                 1000.0   0.0   10000.0  10.0
#pragma parameter hcrt_lcd_resolution                "    Display's Resolution: 1080p | 4K | 8K"                    1.0      0.0   2.0      1.0
#pragma parameter hcrt_lcd_subpixel                  "    Display's Subpixel Layout: RGB | RWBG (OLED) | BGR"       0.0      0.0   2.0      1.0
#pragma parameter hcrt_colour_space                  "    Colour Space: r709 | sRGB | Adobe | DCI-P3 | r2020"       0.0      0.0   4.0      1.0
#pragma parameter hcrt_colour_boost_factor           "    Colour Boost"                                             1.0      0.0   5.0      0.01
#pragma parameter hcrt_space2                        " "                                                            0.0      0.0   0.0001   0.0001

#pragma parameter hcrt_sdr_mode_settings             "SDR MODE SETTINGS"                                            0.0      0.0   0.0001   0.0001
#pragma parameter hcrt_r709_gamma_out                "    r709 Gamma"                                          		2.22     1.0   5.0      0.01
#pragma parameter hcrt_srgb_gamma_out                "    sRGB Gamma"                                          		2.4      1.0   5.0      0.01
#pragma parameter hcrt_p3_gamma_out                  "    DCI-P3 Gamma"                                        		2.6      1.0   5.0      0.01
#pragma parameter hcrt_adobe_gamma_out               "    Adobe Gamma"                                              2.2      1.0   5.0      0.01
#pragma parameter hcrt_r709_gamma_cutoff             "    r709 Gamma Cutoff (x1000)"                           		1.0      0.0   100.0    1.00
#pragma parameter hcrt_srgb_gamma_cutoff             "    sRGB Gamma Cutoff (x1000)"                           		1.0      0.0   100.0    1.00
#pragma parameter hcrt_space3                        " "                                                            0.0      0.0   0.0001   0.0001

#pragma parameter hcrt_crt_physicals                 "CRT SETTINGS:"                                                0.0      0.0   0.0001   0.0001
#pragma parameter hcrt_crt_screen_type               "    Screen Type: APERTURE GRILLE | SHADOW MASK | SLOT MASK"   0.0      0.0   2.0      1.0
#pragma parameter hcrt_crt_resolution                "    Resolution: 300TVL | 600TVL | 800TVL | 1000TVL"           1.0      0.0   3.0      1.0
#pragma parameter hcrt_colour_system                 "    Colour System: r709 | PAL | NTSC-U | NTSC-J"              0.0      0.0   3.0      1.0
#pragma parameter hcrt_phosphor_set                  "    Phosphors: NONE | P22-J | P22-80 | P22-90 | RPTV | 1953"  0.0      0.0   5.0      1.0
#pragma parameter hcrt_space5                        " "                                                            0.0      0.0   0.0001   0.0001
#pragma parameter hcrt_developer_settings0           "    VERTICAL SETTINGS:"                                       0.0      0.0   0.0001   0.0001
#pragma parameter hcrt_v_size                        "        Vertical Size"                                        1.00     0.8   1.2      0.01
#pragma parameter hcrt_v_cent                        "        Vertical Center"                                      0.00  -200.0 200.0      1.0
#pragma parameter hcrt_red_vertical_convergence      "        Red Vertical Deconvergence"                           0.00     -10.0 10.0     0.01
#pragma parameter hcrt_green_vertical_convergence    "        Green Vertical Deconvergence"                         0.00     -10.0 10.0     0.01
#pragma parameter hcrt_blue_vertical_convergence     "        Blue Vertical Deconvergence"                          0.00     -10.0 10.0     0.01
#pragma parameter hcrt_red_scanline_min              "        Red Scanline Min"                                     0.50     0.0   2.0      0.01 
#pragma parameter hcrt_red_scanline_max              "        Red Scanline Max"                                     1.00     0.0   2.0      0.01 
#pragma parameter hcrt_red_scanline_attack           "        Red Scanline Attack"                                  0.20     0.0   1.0      0.01
#pragma parameter hcrt_green_scanline_min            "        Green Scanline Min"                                   0.50     0.0   2.0      0.01 
#pragma parameter hcrt_green_scanline_max            "        Green Scanline Max"                                   1.00     0.0   2.0      0.01 
#pragma parameter hcrt_green_scanline_attack         "        Green Scanline Attack"                                0.20     0.0   1.0      0.01
#pragma parameter hcrt_blue_scanline_min             "        Blue Scanline Min"                                    0.50     0.0   2.0      0.01 
#pragma parameter hcrt_blue_scanline_max             "        Blue Scanline Max"                                    1.00     0.0   2.0      0.01 
#pragma parameter hcrt_blue_scanline_attack          "        Blue Scanline Attack"                                 0.20     0.0   1.0      0.01
#pragma parameter hcrt_space9                        " "                                                            0.0      0.0   0.0001   0.0001
#pragma parameter hcrt_developer_settings1           "    HORIZONTAL SETTINGS:"                                     0.0      0.0   0.0001   0.0001
#pragma parameter hcrt_h_size                        "        Horizontal Size"                                      1.00     0.8   1.2      0.01
#pragma parameter hcrt_h_cent                        "        Horizontal Center"                                    0.00  -200.0 200.0      1.0
#pragma parameter hcrt_red_horizontal_convergence    "        Red Horizontal Deconvergence"                         0.00     -10.0 10.0     0.01
#pragma parameter hcrt_green_horizontal_convergence  "        Green Horizontal Deconvergence"                       0.00     -10.0 10.0     0.01
#pragma parameter hcrt_blue_horizontal_convergence   "        Blue Horizontal Deconvergence"                        0.00     -10.0 10.0     0.01
#pragma parameter hcrt_red_beam_sharpness            "        Red Beam Sharpness"                                   1.75     0.0   5.0      0.05
#pragma parameter hcrt_red_beam_attack               "        Red Beam Attack"                                      0.50     0.0   2.0      0.01
#pragma parameter hcrt_green_beam_sharpness          "        Green Beam Sharpness"                                 1.75     0.0   5.0      0.05
#pragma parameter hcrt_green_beam_attack             "        Green Beam Attack"                                    0.50     0.0   2.0      0.01
#pragma parameter hcrt_blue_beam_sharpness           "        Blue Beam Sharpness"                                  1.75     0.0   5.0      0.05
#pragma parameter hcrt_blue_beam_attack              "        Blue Beam Attack"                                     0.50     0.0   2.0      0.01

#pragma parameter hcrt_image_controls                "IMAGE ADJUSTMENT SETTINGS:"                                   0.0      0.0   0.0001   0.0001
#pragma parameter hcrt_support3                      "    Default white points for the different colour systems:"   0.0      0.0   0.0001   0.0001
#pragma parameter hcrt_support4                      "    709: D65, PAL: D65, NTSC-U: D65, NTSC-J: D93"         	0.0      0.0   0.0001   0.0001
#pragma parameter hcrt_space6                        " "                                                            0.0      0.0   0.0001   0.0001
#pragma parameter hcrt_white_temperature_D65         "    D65 White Temperature (Kelvin)"                    		6504.0   0.0   18500.0  100.0
#pragma parameter hcrt_white_temperature_D93         "    D93 White Temperature (Kelvin)"                    		9305.0   0.0   18500.0  100.0
#pragma parameter hcrt_brightness                    "    Brightness"                                               0.0     -1.0   1.0      0.01
#pragma parameter hcrt_contrast                      "    Contrast"                                                 0.0     -1.0   1.0      0.01
#pragma parameter hcrt_saturation                    "    Saturation"                                               0.0     -1.0   1.0      0.01
#pragma parameter hcrt_gamma_in                      "    Gamma"                                                    2.22     1.0   5.0      0.01
#pragma parameter hcrt_gamma_cutoff                  "    Inverse Gamma Cutoff (x1000)"                             1.0      0.0   100.0    1.0
#pragma parameter hcrt_bloom_strength                "    Bloom Strength"                                           0.0      0.0   1.0      0.01
#pragma parameter hcrt_space7                        " "                                                            0.0      0.0   0.0001   0.0001

