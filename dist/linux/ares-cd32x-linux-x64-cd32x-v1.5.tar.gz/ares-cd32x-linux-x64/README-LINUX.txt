ares CD32X v1.5 for Linux x64 (built from MicroNut99/ares_android 240bdf5 = tag cd32x-v1.5 + README).
Built on Ubuntu 24.04 (glibc 2.39), Release, generic x86-64.

  bin/ares            the emulator (GTK3 window): ./bin/ares
  bin/ares-headless   the scripted runner (the same one the CD32X ports are tested with)
  bin/bios/           your Sega CD BIOS (bios_CD_U.bin ...), see bin/bios/README.txt
  bin/Systems/        RAM carts, EverDrive carts, backup RAM
  share/ares/         Database and Shaders (keep share/ next to bin/)

Needs (Ubuntu / Debian names):
  sudo apt install libgtk-3-0 libopenal1 libao4 libasound2t64 libpulse0 libudev1 libgl1 libxrandr2
Shaders are off in this build (no librashader for Linux here); the picture is unaffected.
Real Sega 32X Hardware Timing, the EverDrive launcher and the RAM carts are in Settings, as on Windows.
Headless: bin/ares-headless --game disc.cue --machine cd32x --bios-us bios.bin --ramcart cart.ram --ramcart-size 16
          (EverDrive: --ramcart-type everdrive --ramcart-boot EDCD.32X); ARES_32X_TIMING=console for the console timing.
